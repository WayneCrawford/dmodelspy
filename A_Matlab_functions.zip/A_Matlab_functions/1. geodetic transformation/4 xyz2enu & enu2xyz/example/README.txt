Validation of matlab functions "xyz2enu.m" and "enu2xyz.m"

augustine xyz.txt       ITRF coordinates of GPS sites from Augustine volcano
enu2xyz.m		matlab function: transform local ENU coordinates to global XYZ coordinates
itrf052itrf00.m		matlab function: transform XYZ from ITRF05 to ITRF00
penu2xyz.m		matlab function: transform local ENU coordinates to global XYZ coordinates (Peter's script)
penu2xyzm.m		matlab function: transformation matrix (Peter's version)
xyz2enu.m			matlab function: transform global XYZ coordinates to local ENU coordinates
xyz2enutest.m		matlab function test			
xyz2enutest.txt		matlab function test (output file)
xyz2llh.m               matlab function: transform XYZ to LLH; frame ITRF00 = WGS84(G1150)
