Validation of matlab function "xyz2llh.m"

htdpep2000.txt			output file from HTDP (epoch 2000 01 01)
itrf052itrf00.m			matlab function: transform XYZ from ITRF05 to ITRF00
SiteITRF05ep2000.txt		XYZ input file: epoch 2000 01 01; frame ITRF05; source www.itf.org
test htdp 2000 01 01.txt		LLH input file: source htdpep2000.txt
xyz2llh.m			matlab function: transform XYZ to LLH; frame ITRF00 = WGS84(G1150)xyz2llhtest.m			matlab function test			
xyz2llhtest.txt			matlab function test (output file)